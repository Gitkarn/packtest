from art import *

output = text2art("Hello World")
print(output)

