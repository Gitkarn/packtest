# packtest

[![PyPI - Version](https://img.shields.io/pypi/v/packtest.svg)](https://pypi.org/project/packtest)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/packtest.svg)](https://pypi.org/project/packtest)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install packtest
```

## License

`packtest` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
